// www.auladoce.com
// jmbp10m@msn.com
#include "tvectorcom.h"
#include <iostream>
using namespace std;

int main(){
	TVectorCom v;

	cout << "Vacio: " << v << endl;
	cout << v.ExisteCom(TComplejo(0, 0)) << endl;
	for(int i = 1; i <= 3; i++){
		v.Redimensionar(v.Tamano() + 1);
		v[v.Tamano()] = TComplejo(i, i);
	}
	if(v.ExisteCom( TComplejo(v.Tamano(), v.Tamano())) == true)
		cout << "Existe" << endl;
	else
		cout << "No existe" << endl;
	cout << v << endl;

	TVectorCom w(v);

	cout << (w == v) << endl;
	w.Redimensionar(v.Tamano() + 2);

	cout << (w == v) << endl;

	return 0;
}
