//www.auladoce.com
//jmbp10m@msn.com
#include <iostream>
#include "tvectorcom.h"
using namespace std;


int main(){
	TVectorCom v(3);

	cout << v.Redimensionar(3) << endl;
	cout << v.Redimensionar(0) << endl;
	cout << v.Redimensionar(-1) << endl;
	v[1] = TComplejo(2, 5);
	v[3] = TComplejo(3, 3);
	cout << v.Redimensionar(6) << endl;
	cout << v << endl;
	
	cout << "Ocupadas: " << v.Ocupadas() << endl;
	cout << ">>>";
	v.MostrarComplejos(3);	
	cout << endl;
	cout << ">>>";
	v.MostrarComplejos(0);
	cout << endl;
	cout << v.Redimensionar(1) << endl;
	cout << v << endl;
	
	

	return 0;
}
