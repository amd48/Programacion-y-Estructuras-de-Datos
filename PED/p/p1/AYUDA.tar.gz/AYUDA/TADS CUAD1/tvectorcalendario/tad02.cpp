#include <iostream>

using namespace std;

#include "tvectorcalendario.h"

int
main(void)
{
   TVectorCalendario a, b(-3), c(4);
   cout << a << endl;
   cout << b << endl;
   cout << c << endl;
   return 0;
}
