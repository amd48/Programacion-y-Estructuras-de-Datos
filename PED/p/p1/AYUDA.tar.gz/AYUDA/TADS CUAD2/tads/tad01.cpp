#include "tcalendario.h"
#include "tvectorcalendario.h"

using namespace std;

int main()
{
	TCalendario c(1, 1, 2000, NULL);
	
	cout << c << endl;

	return 0;
}
