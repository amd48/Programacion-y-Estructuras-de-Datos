/*
 * TVectorCalendario.h
 *
 *  Created on: 4 feb. 2018
 *      Author: otakdeged
 */

#ifndef TVECTORCALENDARIO_H_
#define TVECTORCALENDARIO_H_
#include "tcalendario.h"


class TVectorCalendario {
	friend ostream & operator <<(ostream &, const TVectorCalendario &);
private:
	TCalendario *c;
	int tamano;
	TCalendario error;

public:
	TVectorCalendario();
	TVectorCalendario(int);
	TVectorCalendario(TVectorCalendario &);
	virtual ~TVectorCalendario();
	TVectorCalendario & operator=(TVectorCalendario &);
	bool operator == (TVectorCalendario &);
	bool operator != (TVectorCalendario &);
	TCalendario & operator [](int);
	TCalendario operator [](int) const ;
	int Tamano()const{return this->tamano;};
	int Ocupadas();
	bool ExisteCal(TCalendario &);
	void MostrarMensaje(int, int, int);
	bool Redimensionar(int);
};

#endif /* TVECTORCALENDARIO_H_ */

