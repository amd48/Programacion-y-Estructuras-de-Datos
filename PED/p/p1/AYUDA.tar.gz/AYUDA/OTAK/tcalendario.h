/*
 * TCalendario.h
 *
 *  Created on: 31 ene. 2018
 *      Author: root
 */

#ifndef TCALENDARIO_H_
#define TCALENDARIO_H_
#include <iostream>
#include <ostream>
#include <stddef.h>
#include <string>
#include <stdio.h>
#include <cstring>
#include <sstream>
using namespace std;

class TCalendario
{
	friend ostream &operator<<(ostream &, const TCalendario &);

	public:
		TCalendario();
		TCalendario(int dia, int mes, int anyo, char* mens);
		TCalendario(TCalendario &t);
		TCalendario &operator=(const TCalendario &t);
		TCalendario operator+(int d);
		TCalendario operator-(int d);
		TCalendario operator++(int n);
		TCalendario &operator++();
		TCalendario operator--(int n);
		TCalendario &operator--();
		bool ModFecha (int d, int m, int a);
		bool operator ==(TCalendario &t);
		bool operator !=(TCalendario &t);
		bool operator>(TCalendario &t);
		bool operator<(TCalendario &t);
		bool esVacio();
		char* Mensaje() const{return this->mens;}
		virtual ~TCalendario();

		int Anyo() const
		{
			return this->anyo;
		}
		int Mes() const
		{
			return this->mes;
		}
		int Dia() const
		{
			return this->dia;
		}

		void ModMensaje(char*);
	private:
		int dia, mes, anyo;
		char* mens;
		bool checkFecha(const int , const int , const int );
		bool bisiesto(int);

};

#endif /* TCALENDARIO_H_ */

