/*
 * TVectorCalendario.cpp
 *
 *  Created on: 4 feb. 2018
 *      Author: otakdeged
 */

#include "../Include/tvectorcalendario.h"

TVectorCalendario::TVectorCalendario() { //Revisar

	(*this).tamano = 0;
	(*this).c = new TCalendario[tamano];
	TCalendario temp;
	(*this).error.operator=(temp);
}

TVectorCalendario::TVectorCalendario(int int1) {	//Revisar - Pensar luego
	if(int1 >= 0)
	{
		(*this).tamano = int1;
		(*this).c = new TCalendario[tamano];
	}
	else
	{
		(*this).tamano = 0;
		(*this).c = new TCalendario[NULL];
	}
	//
}

TVectorCalendario::TVectorCalendario(TVectorCalendario&t) {

	(*this).~TVectorCalendario();
	(*this).tamano = t.Tamano();
	(*this).c = new TCalendario [(*this).tamano];
}

TVectorCalendario::~TVectorCalendario()
{
	delete [] this;
	(*this).tamano = 0;
	(*this).c =  new TCalendario[tamano];
}

TVectorCalendario& TVectorCalendario::operator=(TVectorCalendario &t)
{
	(*this).tamano = t.Tamano();
	(*this).c = new TCalendario[(*this).Tamano()];

	for(int i = 0; i < t.tamano; i++)
	{
		c[i] = t.c[i];
	}

	return (*this);
}

bool TVectorCalendario::operator ==(TVectorCalendario &t)
{
	if((*this).Tamano() == t.Tamano())
	{
		for(int i = 0; i < (*this).Tamano(); i++)
		{
			if((*this).c[i].operator!= (t.c[i]))
			{
				return false;
			}
		}
		return true;
	}
	return false;
}

bool TVectorCalendario::operator !=(TVectorCalendario&t)
{
	return !(*this).operator==(t);
}

TCalendario& TVectorCalendario::operator [](int int1)
{
	if(int1 > 0 && (*this).tamano > int1 && (*this).c != NULL)
	{
		return c[int1 -1];
	}
	return error;
}

TCalendario TVectorCalendario::operator [](int int1) const
{
	TCalendario cal;
	if(int1 > 0 && (*this).tamano > int1 && (*this).c != NULL)
	{
		return c[int1 -1];
	}
	return cal;
}

int TVectorCalendario::Ocupadas()
{
	TCalendario vacio;
	int ocupadas = 0;

	for (int i = 0; i < (*this).Tamano(); i++)
	{
		if(c[i].operator!=(vacio))
		{
			ocupadas++;
		}
	}

	return ocupadas;
}

bool TVectorCalendario::ExisteCal(TCalendario&)
{
	return !(*this).c[0].esVacio();
}

void TVectorCalendario::MostrarMensaje(int d, int m, int a)
{
	cout << "[";

	for (int i = 0; i < (*this).tamano; i++)
	{
		if(c[i].Dia() >= d && c[i].Mes() >= m && c[i].Anyo() >= a)
		{
			cout << c[i];

			for(; i<(*this).tamano; i++)
			{
				cout << ", " << c[i];
			}
		}
	}
	cout << "]";
}

bool TVectorCalendario::Redimensionar(int int1)
{
	if( (int1 == (*this).Tamano()) || (int1 <= 0) )
	{
		return false;
	}
	else
	{
		(*this).tamano = int1;
		return true;
	}
}

ostream &operator<<(ostream &o, const TVectorCalendario &t)
{
	o << "[";
	if(t.Tamano() > 0)
	{
		for (int i = 0; i<t.Tamano(); i++)
		{
			o<< "(" << i + 1 << ") " << t.c[i];
			if(i < t.Tamano())
			{
				o << ", ";
			}
		}
	}
	return o;
}
