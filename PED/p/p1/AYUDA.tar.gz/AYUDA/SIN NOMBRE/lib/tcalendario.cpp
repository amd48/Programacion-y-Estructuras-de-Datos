#include "../include/tcalendario.h"
#include <string.h>


TCalendario::TCalendario() {
	dia=1;
	mes=1;
	anyo=1990;
	mensaje=NULL;
}
TCalendario::TCalendario(int d, int m, int a, char * mens){

	bool correcto=false;

	if(a<1900)//Si el año es menor que 1900 no es valido
	{
		correcto=false;
	}
	else if(m<=0 || m>12)//Si no es un mes valido.
	{
		correcto=false;
	}
	else if(m==2)//Si el mes es Febrero.
	{
		if((a%4==0 && a%100!=0 ) || a%400==0 )//Si el año es bisiesto Febrero no tiene 28 dias, tiene 29;
		{
			if(d>0 && d<=29 )
			{
				correcto=true;
			}
			else
			{
				correcto=false;
			}
		}
		else
		{
			if(d>0 && d<=28)
			{
				correcto=true;
			}
			else
			{
				correcto=false;
			}
		}
	}
	else if(m==4 || m==6 || m==9 ||m==11)//Si es un mes de 30 dias
	{
		if(d>0 && d<=30 )
		{
			correcto=true;
		}
		else
		{
			correcto=false;
		}
	}
	else//Los meses que quedan, de 31 dias
	{
		if(d>0 && d<=31 )
		{
			correcto=true;
		}
		else
		{
			correcto=false;
		}
	}
	if(correcto==true)
	{
		dia=d;
		mes=m;
		anyo=a;

		if(mens!=NULL)
		{
			mensaje= new char[strlen(mens)+1];// reservas tamaño de mens +1 de /0
			strcpy(mensaje,mens);//Copio el mens con new
		}
		else
		{
			mensaje=NULL;
		}
	}
	else
	{
		dia=1;
		mes=1;
		anyo=1900;
		if(mens!=NULL)//Llevar Cuidado!!!
		{
			delete[] mensaje;//Borro a los char a los que apuntaba.(importante para no dejar memoria a la que no apunte nada)
			mensaje=NULL;//Hago que no apunte a nada.
		}
		else
		{
			mensaje=NULL;
		}
	}
}
//Contructor de copia (Cuidado con el const)
TCalendario::TCalendario(const TCalendario &a){

	Copia(a);

}
TCalendario::~TCalendario() {
	dia=1;
	mes=1;
	anyo=1900;

	if(mensaje!=NULL)
	{
		delete[] mensaje;//Borro a los char a los que apuntaba.(importante para no dejar memoria a la que no apunte nada)
		mensaje=NULL;//Hago que no apunte a nada.
	}
}
void
TCalendario::Copia(const TCalendario &a)
{
	dia=a.dia;
	mes=a.mes;
	anyo=a.anyo;
	if(a.mensaje!=NULL)//CUIDADO
	{
		mensaje= new char[strlen(a.mensaje)+1];
		strcpy(mensaje,a.mensaje);
	}
	else
	{
		mensaje=NULL;
	}
}
TCalendario&//Lo devuelvo por referencia para que me devuelva el mismo objeto
TCalendario::operator=(const TCalendario &op2)//Al pasarle un valor temporal c++ no quiere que accidentalmente lo modifiques por lo que hay que añadir el const.
{
	if(this != &op2)//Comparo dos punteros, para asegurar la autoasignación(que no apunten al mismo objeto)
	{
		(*this).~TCalendario();//Invoco al destructor para destruir al obj de la izquierda y que pueda almacenar el nuevo.
		Copia(op2);//Copio el de la derecha en la izquierda
	}
	return *this;//Devuelvo el propio objeto para permitir la concatenación de operadores.
}
TCalendario//Al ser una variable local al salirse de ambito se destruye por eso hay que devolverla por valor
TCalendario::operator+(const  int &dias)
{
	if(dias>0)
	{
		bool stop=false;
		TCalendario temp(*this);//Creo una variable temporal para devolverla por valor
		temp.dia=temp.dia+dias;

		while (stop==false)
		{
			if(temp.mes==2)//Si el mes del miembro de la izq es febrero
			{
				if((temp.anyo%4==0 && temp.anyo%100!=0 ) || temp.anyo%400==0 )//Compruebo si el año del miembro de la izq es bisiesto
				{
					stop=ajustarFechaSuma(temp,29);
				}
				else
				{
					stop=ajustarFechaSuma(temp,28);
				}
			}
			else if(temp.mes==4 ||temp.mes==6 || temp.mes==9 ||temp.mes==11)//30 dias
			{
				stop=ajustarFechaSuma(temp,30);
			}
			else//31
			{
				if(temp.mes==12)
				{
					if(temp.dia>31)//Si lo es compruebo si los dias son mas de los que ese mes puede almacenar
					{
						temp.dia=temp.dia-31;
						temp.mes=1;
						temp.anyo++;
					}
					if(temp.dia<=31)
					{
						stop=true;
					}
				}
				else
				{
					stop=ajustarFechaSuma(temp,31);
				}
			}
		}
		return temp;
	}

	return *this;
}
bool
TCalendario::ajustarFechaSuma(TCalendario &temp, int dia)//Paso temp por referencia para poder modificarlo.
{
	bool stop=false;
	int aux=temp.mes;
	if(temp.dia>dia)//Si lo es compruebo si los dias son mas de los que ese mes puede almacenar
	{
		temp.dia=temp.dia-dia;
		temp.mes++;
	}
	if(temp.dia<=dia && aux==temp.mes)//Al restar los dias de ese mes, se comprueba que el mes no ha cambiado,ya que hay que comprobar si los dias actuales son correctos para el mes en el que se encuentra.
	{
		stop=true;
	}
	return stop;
}
TCalendario
TCalendario::operator-(const int &dias)
{
	bool stop=false;
	TCalendario temp(*this);
	if(temp.dia>dias)//Si los dias del mes son mas que los que hay que restar se restan y ya.
	{
		temp.dia=temp.dia-dias;
		return temp;
	}
	else//Si hay iguales dias a restar o mas dias a restar a los dias actuales del mes...
	{
		temp.dia=temp.dia-dias;//Resto los dias que hay que restar para luego ir sumando.
		while(stop==false)
		{
			if(temp.mes-1==2)
			{
				if((temp.anyo%4==0 && temp.anyo%100!=0 ) || temp.anyo%400==0 )//Si es bisiesto
				{
					stop=ajustarFechaResta(temp,29);
				}
				else//si no es bisiesto
				{
					stop=ajustarFechaResta(temp,28);
				}

			}
			else if(temp.mes-1==4 ||temp.mes-1==6 || temp.mes-1==9 ||temp.mes-1==11)//Meses de 30 dias
			{
				stop=ajustarFechaResta(temp,30);
			}
			else//
			{
				if(temp.mes-1==0)//llevar cuidado
				{
					if(temp.dia==0)
					{
						if(temp.anyo-1<1900)
						{
							temp.~TCalendario();//Comprobar si peta llamo al destructor de TCalendario para inicializarlo a lo que me piden
							stop=true;
						}
						else
						{
							temp.mes=12;
							temp.dia=31;
							temp.anyo--;
							stop=true;
						}
					}
					else if((temp.dia+31)>0)
					{
						if(temp.anyo-1<1900)
						{
							temp.~TCalendario();//Comprobar si peta llamo al destructor de TCalendario para inicializarlo a lo que me piden
							stop=true;
						}
						else
						{
							temp.mes=12;
							temp.dia=temp.dia+31;
							temp.anyo--;
							stop=true;
						}
					}
					else if((temp.dia+30)<=0)
					{
						if(temp.anyo-1<1900)
						{
							temp.~TCalendario();//Comprobar si peta llamo al destructor de TCalendario para inicializarlo a lo que me piden
							stop=true;
						}
						else
						{
							temp.mes=12;
							temp.dia=temp.dia+31;
							temp.anyo--;
							stop=false;
						}
					}
				}
				else
				{
					stop=ajustarFechaResta(temp,31);
				}
			}
		}
		return temp;
	}
}
bool
TCalendario::ajustarFechaResta(TCalendario &temp, int dia)//Paso temp por referencia para poder modificarlo.
{
	bool stop=false;
	if(temp.dia==0)
	{
		temp.mes--;
		temp.dia=dia;
		stop=true;
	}
	else if((temp.dia+dia)>0)
	{
		temp.mes--;
		temp.dia=temp.dia+dia;
		stop=true;
	}
	else if((temp.dia+dia)<=0)
	{
		temp.mes--;
		temp.dia=temp.dia+dia;
		stop=false;
	}
	return stop;
}


