#ifndef INCLUDE_TCalendario_H_
#define INCLUDE_TCalendario_H_

class TCalendario	{

public:
	TCalendario();
	TCalendario(int, int, int ,char*);
	TCalendario(const TCalendario &);//Cuidado con el const
	~TCalendario();
	TCalendario & operator=(const TCalendario &);
	TCalendario operator+(const int &);//Añadido const & tener en cuenta
	TCalendario operator-(const int &);


	int dia,mes,anyo;
	char* mensaje;
	void Copia(const TCalendario &c);//Método auxiliar
	bool ajustarFechaSuma(TCalendario &, int);
	bool ajustarFechaResta(TCalendario &, int);

};
#endif
