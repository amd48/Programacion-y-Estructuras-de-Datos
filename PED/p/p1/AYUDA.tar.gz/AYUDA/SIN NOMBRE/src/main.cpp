#include <iostream>
#include <string.h>
using namespace std;

#include "../include/tcalendario.h"

int main()
{
	char d[]="hola";
	char* c=new char[strlen(d)+1];
	strcpy(c,d);

	TCalendario a (1,2,2000,c);
	TCalendario b(20,2,1998,NULL);

	a=b-60;
	cout << "hola" << endl;
	cout << a.dia <<" "<< a.mes << " "<< a.anyo <<" "<< endl;


}
